import RecommendFormHeader from './RecommendFormHeader'
import RecommendMail from './RecommendMail'
import SuccessRecommendModal from './SuccessRecommendModal'

export {
  RecommendFormHeader,
  RecommendMail,
  SuccessRecommendModal
}