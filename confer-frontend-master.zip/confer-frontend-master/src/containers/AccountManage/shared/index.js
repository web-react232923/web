import AccountLayout from './AccountLayout'

export {
  AccountLayout
}