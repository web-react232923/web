module.exports = [
  {
    value: 'Jan',
    label: 'Jan'
  },
  {
    value: 'Feb',
    label: 'Feb'
  },
  {
    value: 'Mar',
    label: 'Mar'
  },
  {
    value: 'Apr',
    label: 'Apr'
  },
  {
    value: 'May',
    label: 'May'
  },
  {
    value: 'Jun',
    label: 'Jun'
  },
  {
    value: 'Jul',
    label: 'Jul'
  },
  {
    value: 'Aug',
    label: 'Aug'
  },
  {
    value: 'Sep',
    label: 'Sep'
  },
  {
    value: 'Oct',
    label: 'Oct'
  },
  {
    value: 'Nov',
    label: 'Nov'
  },
  {
    value: 'Dec',
    label: 'Dec'
  }
];