module.exports = [
  {
    value: -1,
    label: 'All years'
  },
  {
    value: 0,
    label: '0 - 2 years'
  },
  {
    value: 3,
    label: '3 - 5 years'
  },
  {
    value: 6,
    label: '6 - 8 years'
  },
  {
    value: 8,
    label: ' > 8 years'
  }
];