export default {
	SET_DEGREES: 'SET_DEGREES'
}