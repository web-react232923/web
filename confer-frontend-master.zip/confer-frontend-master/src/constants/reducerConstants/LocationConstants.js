export default {
	SET_LOCATIONS: 'SET_LOCATIONS'
}