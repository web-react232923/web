export default {
  GET_ERRORS: 'GET_ERRORS'
}