export default {
	SET_USERS: 'SET_USERS'
}