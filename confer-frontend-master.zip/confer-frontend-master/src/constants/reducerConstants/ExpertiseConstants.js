export default {
	SET_EXPERTISES: 'SET_EXPERTISES'
}