export default {
	SET_SKILLS: 'SET_SKILLS'
}