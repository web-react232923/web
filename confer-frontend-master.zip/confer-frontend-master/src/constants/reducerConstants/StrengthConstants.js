export default {
	SET_STRENGTHS: 'SET_STRENGTHS'
}