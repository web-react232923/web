export default {
	SET_GROUPS: 'SET_GROUPS'
}