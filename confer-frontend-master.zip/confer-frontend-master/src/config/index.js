module.exports = {
    proxyUrl: 'https://confer-backend.herokuapp.com'
};